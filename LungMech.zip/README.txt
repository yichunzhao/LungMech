This version of LungMech is mainly made by Yichun.
It is known to work on the 4. of juli 2006... just
before lunch :-)

For the software to work in netbeans you manually
have to include the 2 .jar archives found in 
/LungMech/LungMech/sharelib/sgt
Use /LungMech as project folder (optional) and
/LungMech/LungMech as source folder.

Furthermore the folder c:\LungMech\data\EntireData
has to excist and the file curvedata.txt must be
placed there. The file is just at empty 
standard .txt-file.